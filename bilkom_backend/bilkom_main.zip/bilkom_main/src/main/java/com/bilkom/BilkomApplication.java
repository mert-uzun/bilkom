package com.bilkom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BilkomApplication {
    public static void main(String[] args) {
        SpringApplication.run(BilkomApplication.class, args);
    }
}